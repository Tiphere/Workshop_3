# Workshop 3: Paxos Consensus and Quorum Validation

COMSM0122 - Fundamentals of System Security

The project contains the workshop consensus experiments and quorum validation as the selected Task 8.1 defence. The report covers Parts 1-8.

## Requirements

Node.js 18 or newer. No external packages are required.

## Run

Open a terminal in the extracted `paxos-lab` folder and run:

```text
node run_workshop.js
```

This executes all eleven scenarios and saves their output to `results/experiments.txt`. On macOS, `Run_Workshop.command` also starts the experiments using an available local Node.js runtime.

Run the verification tests with:

```text
node --test tests/workshop.test.js
```

Individual scenarios can also be run using the following commands:

| Part | Command |
| --- | --- |
| 1 | `node scenarios/happy_path.js` |
| 2 | `node scenarios/acceptor_failure.js` |
| 3 | `node scenarios/competing_proposers.js` |
| 4 | `node scenarios/partial_acceptance.js` |
| 5 | `node scenarios/preserve_chosen_value.js` |
| 6 | `node scenarios/multi_paxos.js` |
| 7.1 | `node scenarios/network_partition.js` |
| 7.2 | `node scenarios/breaking_assumptions/majority_loss.js` |
| 7.3 | `node scenarios/breaking_assumptions/state_loss.js` |
| 7.4 | `node scenarios/breaking_assumptions/quorum_misconfiguration.js` |
| 8 | `node scenarios/hardening.js` |

## Implementation

- `validated_simulator.js` rejects non-integer, sub-majority or impossible quorum thresholds before proposing, then uses the checked value for both phases.
- The partial-acceptance scenario uses replacement ballot 102 to recover the accepted value at 101.
- The ordered-instance scenario retains separate state for four slots. It runs both phases for each entry and does not implement phase-skipping Multi-Paxos.
- The quorum-misconfiguration scenario compares quorum three with quorum two using disjoint active pairs of a fixed five-member deployment.

The validation class is used by the hardening scenario. Earlier failure demonstrations intentionally retain the original simulator. The network example is standalone, protocol state is in memory, and proposer ballot uniqueness across independent processes is not implemented automatically.

## Documentation

- `REPORT.md`: observations, explanations, implementation and limitations.
- `results/experiments.txt`: recorded output from all eleven scenarios.
- `results/tests.txt`: recorded output from five verification tests.
