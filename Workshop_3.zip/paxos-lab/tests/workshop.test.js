const test = require("node:test");
const assert = require("node:assert/strict");
const { spawnSync } = require("node:child_process");
const path = require("node:path");
const Proposer = require("../proposer");
const Acceptor = require("../acceptor");
const Learner = require("../learner");
const ValidatedSimulator = require("../validated_simulator");

const createAcceptors = () => ["A1", "A2", "A3", "A4", "A5"].map(id => new Acceptor(id));

test("unsafe configurations are rejected before a proposal starts", () => {
    const proposer = new Proposer("P1");
    for (const threshold of [0, 1, 2, 2.5, 6, "3", NaN]) {
        assert.throws(
            () => new ValidatedSimulator(proposer, createAcceptors(), [], { majority: () => threshold }),
            /Unsafe quorum size/
        );
    }
    assert.throws(() => new ValidatedSimulator(proposer, [], []), /Unsafe quorum size/);
    assert.equal(proposer.proposalNumber, 100);
});

test("validated runs choose and then preserve the existing value", () => {
    const acceptors = createAcceptors();
    const first = new Learner("L1");
    new ValidatedSimulator(new Proposer("P1"), acceptors, [first]).run("instances=12");
    assert.equal(first.value, "instances=12");

    const proposer = new Proposer("P2");
    proposer.proposalNumber = 101;
    const second = new Learner("L2");
    new ValidatedSimulator(proposer, acceptors, [second]).run("instances=20");
    assert.equal(second.value, "instances=12");
});

test("custom counting code cannot bypass the validated majority", () => {
    const acceptors = createAcceptors();
    acceptors.slice(2).forEach(a => a.fail());
    const learner = new Learner("L1");
    new ValidatedSimulator(new Proposer("P1"), acceptors, [learner], {
        majority: () => 3,
        reached: () => true
    }).run("instances=10");
    assert.equal(learner.value, null);
    assert.ok(acceptors.every(a => a.acceptedProposal === null));
});

test("partial acceptance uses ballot 102 and carries value 10 forward", () => {
    const result = spawnSync(process.execPath, [path.join(__dirname, "../scenarios/partial_acceptance.js")], { encoding: "utf8" });
    assert.equal(result.status, 0, result.stderr);
    assert.match(result.stdout, /A1 reports previously accepted/);
    assert.match(result.stdout, /VALUE CHOSEN: instances=10/);
    assert.doesNotMatch(result.stdout, /VALUE CHOSEN: instances=20/);
});

test("different log slots retain separate accepted values", () => {
    const { slots, log } = require("../scenarios/multi_paxos");
    assert.deepEqual(log.map(entry => entry.ballot), [101, 102, 103, 104]);
    assert.deepEqual(log.map(entry => entry.chosen), [10, 20, 30, 40].map(n => `instances=${n}`));
    assert.equal(slots[0].acceptors[0].acceptedProposal.value, "instances=10");
    assert.equal(slots[1].acceptors[0].acceptedProposal.value, "instances=20");
});
