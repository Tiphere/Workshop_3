#!/bin/zsh
cd "$(dirname "$0")" || exit 1
workshop_node="$(command -v node)"
if [[ -z "$workshop_node" ]]; then
    workshop_node="$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node"
fi
if [[ -x "$workshop_node" ]]; then
    "$workshop_node" run_workshop.js
else
    print "Node.js 18 or newer is required."
fi
read -r "workshop_reply?Press Enter to close."
