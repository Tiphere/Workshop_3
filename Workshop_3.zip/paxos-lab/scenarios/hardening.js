const Proposer = require("../proposer");
const Acceptor = require("../acceptor");
const Learner = require("../learner");
const ValidatedSimulator = require("../validated_simulator");

console.log("PART 8: QUORUM VALIDATION");
const acceptors = ["A1", "A2", "A3", "A4", "A5"].map(id => new Acceptor(id));
const proposer = new Proposer("P1");
const learner = new Learner("L1");

console.log("\nAttempt to configure quorum 2 of 5");
try {
    new ValidatedSimulator(proposer, acceptors, [learner], { majority: () => 2 });
    throw new Error("Unsafe configuration was accepted.");
} catch (error) {
    if (!error.message.startsWith("Unsafe quorum size:")) throw error;
    console.log(`CONFIGURATION REJECTED: ${error.message}`);
}
console.log(`Proposal counter after rejection: ${proposer.proposalNumber}`);

console.log("\nRun with the correct quorum 3 of 5");
new ValidatedSimulator(proposer, acceptors, [learner]).run("instances=10");
