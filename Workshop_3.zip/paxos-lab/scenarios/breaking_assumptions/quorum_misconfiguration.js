const Proposer = require("../../proposer");
const Acceptor = require("../../acceptor");
const Learner = require("../../learner");
const Simulator = require("../../simulator");

function compareQuorum(threshold) {
    console.log(`\nConfigured quorum: ${threshold} of 5`);
    const acceptors = ["A1", "A2", "A3", "A4", "A5"].map(id => new Acceptor(id));
    const first = new Learner("L1");
    const second = new Learner("L2");

    function runWithPair(ids, proposer, learner, value) {
        for (const acceptor of acceptors) {
            if (ids.includes(acceptor.id)) acceptor.recover();
            else acceptor.fail();
        }
        const simulator = new Simulator(proposer, acceptors, [learner]);
        // Deliberately bypass validation to demonstrate an unsafe configuration.
        simulator.quorum = {
            majority: () => threshold,
            reached: count => count >= threshold
        };
        simulator.run(value);
    }

    runWithPair(["A1", "A2"], new Proposer("P1"), first, "instances=10");
    const replacement = new Proposer("P2");
    replacement.proposalNumber = 101;
    runWithPair(["A4", "A5"], replacement, second, "instances=20");

    console.log(`First learned value: ${first.value}`);
    console.log(`Second learned value: ${second.value}`);
    if (first.value !== null && second.value !== null && first.value !== second.value) {
        console.log("SAFETY VIOLATION: conflicting values chosen for the same instance.");
    } else {
        console.log("No conflicting chosen values; neither active pair reaches quorum 3.");
    }
}

console.log("SCENARIO: QUORUM MISCONFIGURATION");
compareQuorum(3);
compareQuorum(2);
