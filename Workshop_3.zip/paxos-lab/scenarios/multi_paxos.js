const Proposer = require("../proposer");
const Acceptor = require("../acceptor");
const Learner = require("../learner");
const Simulator = require("../simulator");

console.log("SCENARIO: ORDERED CONSENSUS INSTANCES");
const proposer = new Proposer("P1");
const slots = [];
const log = [];

for (const [index, count] of [10, 20, 30, 40].entries()) {
    const slot = index + 1;
    // These objects hold separate state for this slot, under the same member IDs.
    const acceptors = ["A1", "A2", "A3"].map(id => new Acceptor(id));
    const learner = new Learner(`L1/slot-${slot}`);
    const simulator = new Simulator(proposer, acceptors, [learner]);

    console.log(`\nSlot ${slot}, proposer ${proposer.id}`);
    simulator.run(`instances=${count}`);
    slots.push({ slot, acceptors, learner });
    log.push({ slot, proposer: proposer.id, ballot: proposer.proposalNumber, chosen: learner.value });
}

console.log("\nOrdered log");
console.table(log);
console.log("P1 coordinates all four slots; both Paxos phases run for every slot.");
module.exports = { slots, log };
