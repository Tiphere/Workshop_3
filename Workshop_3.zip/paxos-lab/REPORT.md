# Workshop 3: Paxos Consensus and Quorum Validation

COMSM0122 - Fundamentals of System Security  
Experimental Report  
Prepared: 21 October 2026

## Method

Eleven scenarios were executed using the supplied JavaScript model. Task 8.1, quorum validation, was selected as the defensive mechanism. The optional extension was not undertaken. Scenario output and test results are recorded in `results/experiments.txt` and `results/tests.txt`.

## Part 1: Understanding Consensus

P1 proposed `instances=10` under ballot 101. Three acceptors returned promises and accepted the proposal. The configured quorum was two, so the value was chosen when majority acceptance occurred. L1 subsequently learned the result. Acceptors supplied the agreement evidence; the learner recorded the result rather than voting. A majority is required because successive majorities intersect and can carry acceptance history into later attempts.

## Part 2: Acceptor Failure

A3 was unavailable. A1 and A2 supplied two promises and two acceptances, meeting the unchanged quorum of two. The chosen value remained `instances=10`. This deployment can retain a majority after one acceptor failure, assuming the remaining nodes communicate and follow the protocol. A second unavailable acceptor would leave only one participant and prevent progress. The result demonstrates majority agreement rather than unanimity.

## Part 3: Competing Proposers

All three acceptors first promised ballot 101, then promised ballot 102. They rejected P1's subsequent requests at 101 and accepted P2's requests at 102. P2 obtained majority acceptance for `instances=10`. The scenario prints acceptance results without invoking a learner. Rejection follows from the higher promise, rather than from the application value or the proposer's identity. Ballot numbers order attempts; a larger number does not establish a better decision or guarantee eventual progress.

## Part 4: Partial Acceptance

A1 initially held `(101, instances=10)`, while no majority had accepted it. P2 preferred `instances=20`. The replacement attempt was corrected to use ballot 102, above A1's existing promise, instead of reusing 101. P2 received all three promises, including A1's history. Since 101 was the highest accepted ballot reported, P2 adopted 10 and obtained three acceptances. The selection rule applies to the consulted quorum's history; a single acceptance does not permanently fix a value in every possible continuation.

## Part 5: Preserving Chosen Values

The acceptors were initialised with `(90, instances=12)`, representing a previously chosen value. P2 attempted to propose `instances=20` under ballot 101. Its promise responses reported the earlier acceptance, so the selected value remained 12. All three acceptors accepted it and L1 learned 12. This preserves agreement within the same consensus instance. A later application update belongs in a different log position rather than replacing this decision.

## Part 6: Multi-Paxos and Stable Proposers

P1 coordinated four distinct slots using ballots 101, 102, 103 and 104. The chosen commands set the instance count to 10, 20, 30 and 40 respectively. Separate per-slot acceptor state was retained under the same member identities, preserving earlier decisions. P1 was supplied as the coordinator throughout; this does not demonstrate automatic leader election or convergence from competing proposers. Both phases run for every slot. The scenario illustrates an ordered sequence of consensus instances, without implementing the Multi-Paxos optimisation that avoids repeated preparation under stable leadership.

## Part 7.1: Network Partitioning

The network model delivered `Prepare(101)` before the partition. During disruption it dropped `Prepare(102)` and `Accept(102, instances=10)`. After repair it delivered `Prepare(103)`. This demonstrates message availability changing with communication state. A partition need not itself imply a conflicting decision. The supplied network object is a standalone message-delivery demonstration: the consensus engine calls acceptors directly. This output therefore does not establish end-to-end consensus behaviour under a network partition.

## Part 7.2: Majority Loss

A2 and A3 were unavailable, leaving one of three acceptors online. Quorum remained two. P1 received one promise and stopped with `FAILED: no quorum of promises`, before acceptance or learning. No new value was chosen. Progress was unavailable, but this execution produced no conflicting decision. Lowering the threshold or silently replacing members would change the assumptions rather than safely recover the missing majority.

## Part 7.3: State Loss

A1 initially stored highest promised ballot 101 and accepted proposal `(101, instances=10)`. The failure cleared these fields to zero and null. The acceptor lost information needed to reject obsolete attempts and report acceptance history. Multiple acceptors forgetting such state could allow later quorums to miss prior decisions. This scenario displays erased state and the resulting risk; it does not execute a conflicting global decision. The model stores state in memory and does not implement durable storage or restart recovery.

## Part 7.4: Quorum Misconfiguration

Five fixed acceptors were used, with two disjoint pairs made available in succession. At quorum three, neither pair could complete Phase 1. At quorum two, A1 and A2 chose `instances=10` under ballot 101. Later, A4 and A5 chose `instances=20` under ballot 102 for the same instance. Their histories had no intersection, and the learners recorded conflicting results. This demonstrates a safety violation caused by an incorrect threshold. Availability flags represent the separated active groups; no physical network partition is executed.

## Part 8: Protecting Quorum Rules

**Failure addressed.** A threshold below majority removes the overlap required by classic Paxos.

**Implementation.** `validated_simulator.js` checks the configuration before starting a proposal. For N acceptors, the threshold must be an integer between `floor(N / 2) + 1` and N. Both phases then use the checked threshold. `scenarios/hardening.js` uses this class; preceding scenarios retain the original simulator for comparison.

**Demonstration.** Quorum two of five was rejected with `Unsafe quorum size`. The proposal counter remained 100, confirming that no attempt had started. With the correct quorum three, the same deployment chose `instances=10`.

**Verification.** Five tests passed: invalid configurations are rejected before proposing; valid runs choose and preserve a value; custom counting code cannot bypass the checked majority; partial acceptance carries 10 forward; and separate slots retain distinct decisions.

**Limitations.** The defence assumes fixed membership and intact implementation code. It does not restore missing acceptors, provide durable state, integrate network delivery or elect a leader. The original proposer counter also does not provide globally unique ballots automatically across independent proposers. The selected change protects quorum configuration within this model rather than implementing a production Paxos service.

## Source

COMSM0122, Workshop 3: Understanding and Stress-Testing Paxos, workshop manual and supplied `paxos-lab` source code.
