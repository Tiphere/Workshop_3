const Simulator = require("./simulator");
const Quorum = require("./quorum");

class ValidatedSimulator extends Simulator {
    constructor(proposer, acceptors, learners, quorum = new Quorum(acceptors.length)) {
        const total = acceptors.length;
        const minimum = Math.floor(total / 2) + 1;
        const threshold = quorum.majority();

        if (
            total === 0 ||
            !Number.isInteger(threshold) ||
            threshold < minimum ||
            threshold > total
        ) {
            throw new Error(
                `Unsafe quorum size: ${threshold}; expected an integer from ${minimum} to ${total}.`
            );
        }

        super(proposer, acceptors, learners);
        // Both phases count votes against the checked threshold.
        this.quorum = Object.freeze({
            majority: () => threshold,
            reached: (count) => count >= threshold
        });
    }
}

module.exports = ValidatedSimulator;
